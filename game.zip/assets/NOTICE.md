Map geometry: Natural Earth, 1:110m, public domain.
https://www.naturalearthdata.com/about/terms-of-use/

Packaged source: world-atlas 2.0.2, countries-110m.json.
https://www.npmjs.com/package/world-atlas

SVG paths are projected and rounded for this offline prototype.
