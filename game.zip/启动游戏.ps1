param([int]$Port = 3000, [switch]$SkipAI, [switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
$nodeCandidates = @(
    $(if ($nodeCommand) { $nodeCommand.Source }),
    (Join-Path $env:LOCALAPPDATA 'Programs\Codex\app\resources\cua_node\bin\node.exe'),
    (Join-Path $env:TEMP 'xianyan-runtime\node.exe')
)
$nodePath = $nodeCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $nodePath) { throw 'Node.js 20+ is required. Install it, then run this script again.' }
if (-not $SkipAI) {
    $lmsPath = Join-Path $env:USERPROFILE '.lmstudio\bin\lms.exe'
    if (Test-Path -LiteralPath $lmsPath) {
        Write-Host 'Preparing local LM Studio service...'
        try {
            $loaded = @((& $lmsPath ps --json) | ConvertFrom-Json)
            $existingModel = Join-Path $env:USERPROFILE '.lmstudio\models\lmstudio-community\DeepSeek-R1-0528-Qwen3-8B-GGUF\DeepSeek-R1-0528-Qwen3-8B-Q4_K_M.gguf'
            if ($loaded.Count -eq 0 -and (Test-Path -LiteralPath $existingModel)) {
                & $lmsPath load deepseek-r1-0528-qwen3-8b --identifier xianyan-materials --context-length 4096 --gpu max --parallel 1 --ttl 3600 --yes | Out-Null
            }
            & $lmsPath server start --port 1234 --bind 127.0.0.1 | Out-Null
        } catch { Write-Host 'AI service unavailable. Built-in materials remain playable.' }
    }
}
$ready = $false
try { $status = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/ai/status" -TimeoutSec 8; $ready = $null -ne $status.checkedAt } catch {}
if (-not $ready) {
    $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($listener) { throw "Port $Port is in use. Run with -Port 3001 or stop the previous game server." }
    $env:PORT = "$Port"
    $serverFile = Join-Path $PSScriptRoot 'server.cjs'
    Start-Process -FilePath $nodePath -ArgumentList ('"' + $serverFile + '"') -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 250
        try { $null = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$Port/" -TimeoutSec 1; $ready = $true; break } catch {}
    }
}
if (-not $ready) { throw 'The game server did not start. Run node server.cjs to inspect the error.' }
Write-Host "Game ready: http://localhost:$Port"
if (-not $NoBrowser) { Start-Process "http://localhost:$Port" }
