const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.BROWSER_PATH || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1512, height: 982 }, reducedMotion: 'reduce' });
    const errors = [];
    page.on('pageerror', (error) => errors.push(error.message));
    const artifacts = path.join(__dirname, '../artifacts');
    fs.mkdirSync(artifacts, { recursive: true });
    await page.goto('http://localhost:3000');
    await page.waitForSelector('.map-node');
    assert.equal(await page.locator('.map-node').count(), 6);
    assert.equal(await page.locator('#land-base path').count(), 176);
    await page.screenshot({ path: path.join(artifacts, 'desktop-v2.png'), fullPage: true });

    await page.click('[data-target="water"]');
    const desertRadius = await page.locator('#radius-value').textContent();
    assert.equal(await page.locator('#radius-unit').textContent(), 'm');
    assert.equal(await page.locator('.local-inset').count(), 1);
    await page.locator('.map-node[data-site="cern"]').click();
    assert.notEqual(await page.locator('#radius-value').textContent(), desertRadius);
    await page.click('#density-details');
    await page.waitForSelector('#modal[open]');
    assert.equal(await page.locator('.density-table tbody tr').count(), 6);
    await page.screenshot({ path: path.join(artifacts, 'density-details.png'), fullPage: true });
    await page.click('#modal-close');
    await page.click('#density-toggle');
    assert.ok(await page.locator('#density-layer rect').count() > 100);
    await page.click('#density-toggle');
    assert.equal(await page.locator('#density-layer rect').count(), 0);

    await page.fill('#material-name', '黄金');
    assert.equal(await page.locator('#launch').isDisabled(), true);
    await page.click('#identify-material');
    assert.equal(await page.locator('#impact-target').textContent(), '金');
    assert.equal(await page.locator('#launch').isEnabled(), true);
    await page.fill('#material-name', 'time');
    await page.click('#identify-material');
    await page.waitForSelector('#material-status.error');
    assert.equal(await page.locator('#quota-number').textContent(), '03');
    assert.equal(await page.locator('#launch').isDisabled(), true);
    await page.click('[data-target="chip"]');
    assert.equal(await page.locator('#launch').isEnabled(), true);

    if (process.env.RUN_LOCAL_AI === '1') {
      await page.uncheck('#online-research');
      await page.fill('#material-name', '聚四氟乙烯');
      await page.click('#force-ai');
      await page.waitForSelector('#material-status.success', { timeout: 170000 });
      assert.equal(await page.locator('#impact-target').textContent(), '聚四氟乙烯');
      await page.screenshot({ path: path.join(artifacts, 'local-ai.png'), fullPage: true });
    }

    await page.route('**/api/material/resolve', async (route) => {
      const name = route.request().postDataJSON().name;
      if (name === '离线测试材料') return route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ error: '本地 AI 未连接，请加载模型。' }) });
      if (name === '零密度测试材料') return route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ material: { name, basis: 'population', coefficient: 0 } }) });
      return route.continue();
    });
    await page.fill('#material-name', '离线测试材料');
    await page.click('#identify-material');
    await page.waitForSelector('#material-status.error');
    assert.match(await page.locator('#material-status').textContent(), /未连接/);
    assert.equal(await page.locator('#quota-number').textContent(), '03');
    await page.fill('#material-name', '零密度测试材料');
    await page.click('#identify-material');
    await page.waitForSelector('#material-status.success');
    assert.equal(await page.locator('#launch').isDisabled(), true);
    assert.equal(await page.locator('#impact-preview path').count(), 0);
    await page.unroute('**/api/material/resolve');

    await page.click('[data-target="chip"]');
    await page.click('#station-toggle');
    await page.locator('.station-option[data-site="east"]').click();
    await page.click('#launch');
    await page.waitForFunction(() => !document.querySelector('#launch').disabled);
    assert.equal(await page.locator('#quota-number').textContent(), '02');
    assert.equal(await page.locator('#total-mass').innerText(), '3,000 t');
    const firstArea = await page.locator('#total-area').textContent();
    await page.locator('.map-node[data-site="ihep"]').click();
    assert.equal(await page.locator('#total-area').textContent(), firstArea);
    await page.locator('.map-node[data-site="east"]').click();
    await page.click('#launch');
    await page.waitForFunction(() => !document.querySelector('#launch').disabled);
    assert.equal(await page.locator('#total-mass').innerText(), '3,000 t');
    assert.equal(await page.locator('#total-area').textContent(), firstArea);
    await page.reload();
    assert.equal(await page.locator('#quota-number').textContent(), '01');
    await page.click('[data-target="hair"]');
    assert.equal(await page.locator('#radius-value').textContent(), '全球');
    await page.locator('.map-node[data-site="ihep"]').click();
    assert.notEqual(await page.locator('#radius-value').textContent(), '全球');
    await page.locator('.map-node[data-site="east"]').click();
    await page.click('#launch');
    await page.waitForSelector('#modal[open]');
    assert.equal(await page.locator('#quota-number').textContent(), '00');
    assert.equal(await page.locator('.report-row').count(), 3);
    await page.screenshot({ path: path.join(artifacts, 'report-v2.png'), fullPage: true });
    await page.reload();
    await page.waitForSelector('#modal[open]');
    await page.click('[data-action="restart"]');
    assert.equal(await page.locator('#quota-number').textContent(), '03');

    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: path.join(artifacts, 'mobile-v2.png'), fullPage: true });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Mobile overflow');
    await page.click('[data-view="archive"]');
    await page.waitForSelector('#modal[open]');
    assert.ok(await page.locator('.archive-list .report-row').count() > 30);
    await page.click('#modal-close');

    const offline = await browser.newPage({ viewport: { width: 1512, height: 982 }, offline: true, reducedMotion: 'reduce' });
    offline.on('pageerror', (error) => errors.push(error.message));
    await offline.goto(pathToFileURL(path.join(__dirname, '../index.html')).href);
    await offline.fill('#material-name', '氧气');
    await offline.click('#identify-material');
    assert.equal(await offline.locator('#impact-target').textContent(), '氧气');
    await offline.fill('#material-name', '词库外测试化合物');
    await offline.click('#identify-material');
    await offline.waitForSelector('#material-status.error');
    assert.equal(await offline.locator('#quota-number').textContent(), '03');
    assert.deepEqual(errors, []);
    console.log('PASS: station density, custom input, AI errors, zero density, world overlay, three collisions, 3000 t cap, snapshot persistence, report, mobile and offline catalog.' + (process.env.RUN_LOCAL_AI === '1' ? ' Real local AI also passed.' : ''));
  } finally { await browser.close(); }
})().catch((error) => { console.error(error); process.exitCode = 1; });
