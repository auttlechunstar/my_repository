const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../simulation.js');

test('3000 tonne formula uses areal inventory, with an equal-area spherical radius', () => {
  const water = E.findMaterial('H₂O');
  const f = E.footprint(water, { water: 30 });
  assert.equal(f.area, 100);
  assert.equal(f.mass, 3000);
  assert.ok(Math.abs(E.areaFor(f.radius) - 100) < 1e-9);
  assert.ok(Math.abs(f.radius - Math.sqrt(100 / Math.PI)) < .001);
});
test('same substance varies by station; hair is not intrinsically global', () => {
  const hair = E.findMaterial('头发');
  const desert = E.footprint(hair, E.PROFILES.east);
  const city = E.footprint(hair, E.PROFILES.ihep);
  assert.equal(desert.global, true);
  assert.equal(desert.area, E.EARTH_AREA);
  assert.equal(city.global, false);
  assert.ok(city.radius < 100);
  assert.ok(desert.mass < 3000);
  assert.equal(city.mass, 3000);
});
test('density zero does not divide by zero or expand to the world', () => {
  const f = E.footprint(E.findMaterial('头发'), { population: 0 });
  assert.deepEqual(f, { density: 0, area: 0, rawArea: null, radius: 0, global: false, mass: 0, available: false });
});
test('all preloaded station/material pairs have finite footprints within the budget', () => {
  for (const m of E.MATERIALS) for (const s of E.SITES) {
    const f = E.footprint(m, E.PROFILES[s.id]);
    assert.ok(Number.isFinite(f.radius) && f.radius >= 0);
    assert.ok(f.area >= 0 && f.area <= E.EARTH_AREA);
    assert.ok(f.mass >= 0 && f.mass <= 3000 + 1e-9);
    assert.ok(Math.abs(E.areaFor(f.radius) - f.area) < Math.max(1e-8, f.area * 1e-12));
  }
});
test('tiny areas stay nonzero and aliases preserve material identity', () => {
  assert.ok(Math.abs(E.areaFor(E.radiusFor(1e-10)) / 1e-10 - 1) < 1e-12);
  assert.equal(E.findMaterial('  WATER  ').id, E.findMaterial('水').id);
  assert.notEqual(E.findMaterial('碳').id, E.findMaterial('碳基').id);
  assert.equal(E.findMaterial('不存在于词库的物质'), undefined);
});
test('AI coefficient validation rejects bad units and invalid numeric values', () => {
  for (const coefficient of [-1, NaN, Infinity]) assert.throws(() => E.validateMaterial({ name: '材料', basis: 'water', coefficient }));
  assert.throws(() => E.validateMaterial({ name: '材料', basis: 'water', coefficient: 2 }));
  assert.throws(() => E.validateMaterial({ name: '材料', basis: 'kg/m3', coefficient: 1 }));
  const m = E.validateMaterial({ name: '新聚合物', basis: 'population', coefficient: .0001 });
  assert.equal(E.density(m, { population: 100 }), .01);
});
