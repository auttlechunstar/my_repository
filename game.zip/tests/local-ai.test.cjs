const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createAIService } = require('../local-ai.cjs');

function fixture(t, output, model = 'test-model') {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'xianyan-ai-test-'));
  const cacheFile = path.join(dir, 'cache.json');
  t.after(() => { for (const file of [cacheFile, cacheFile + '.tmp']) if (fs.existsSync(file)) fs.unlinkSync(file); fs.rmdirSync(dir); });
  let calls = [];
  const fetchImpl = async (url, options) => {
    calls.push({ url, options });
    if (url.endsWith('1234/v1/models')) return { ok: true, json: async () => ({ data: [{ id: model }] }) };
    if (url.endsWith('11434/api/tags')) {
      if (model === null) return { ok: true, json: async () => ({ models: [{ name: 'nomic-embed-text' }, { name: 'qwen3:4b' }] }) };
      throw new Error('No Ollama');
    }
    if (url.includes('wikipedia.org')) throw new Error('Network offline');
    if (url.endsWith('/v1/chat/completions')) return { ok: true, json: async () => ({ choices: [{ message: { content: JSON.stringify(output) } }] }) };
    if (url.endsWith('/v1/completions')) return { ok: true, json: async () => ({ choices: [{ text: JSON.stringify(output) }] }) };
    if (url.endsWith('/api/chat')) return { ok: true, json: async () => ({ message: { content: JSON.stringify(output) } }) };
    throw new Error('Unexpected request: ' + url);
  };
  return { ai: createAIService({ fetchImpl, cacheFile }), calls, cacheFile };
}
test('known aliases resolve without an AI or external request', async (t) => {
  const { ai, calls } = fixture(t, {});
  const result = await ai.resolve({ name: 'H2O' });
  assert.equal(result.material.id, 'water');
  assert.equal(calls.length, 0);
});
test('unknown material uses a local model, marks network failure, and caches its coefficient', async (t) => {
  const { ai, calls } = fixture(t, { isMaterial: true, name: '测试聚合物', basis: 'population', coefficient: .0002, description: '测试材料', reasoning: '估算约每人 200 g' });
  const result = await ai.resolve({ name: '测试聚合物', online: true });
  assert.equal(result.material.coefficient, .0002);
  assert.equal(result.material.source, 'ai');
  assert.equal(result.material.evidence.status, 'unavailable');
  assert.equal(result.material.evidence.sources.length, 0);
  const cache = await ai.resolve({ name: '测试聚合物', online: false });
  assert.equal(cache.cached, true);
  assert.equal(calls.filter((c) => c.url.endsWith('/v1/chat/completions')).length, 1);
});
test('abstract concepts and malformed estimates are rejected', async (t) => {
  const rejected = fixture(t, { isMaterial: false, name: '幸福', basis: 'population', coefficient: 0, description: '', reasoning: '幸福不是具体物质。' });
  await assert.rejects(rejected.ai.resolve({ name: '幸福', online: false }), { status: 422 });
  const malformed = fixture(t, { isMaterial: true, name: '未知元素', basis: 'water', coefficient: -4 });
  await assert.rejects(malformed.ai.resolve({ name: '未知元素', online: false }), { status: 422 });
});
test('missing AI service gives an actionable error; no fallback numbers are fabricated', async () => {
  const ai = createAIService({ fetchImpl: async () => { throw new Error('Unavailable'); }, cacheFile: 'nonexistent-material-cache.json' });
  await assert.rejects(ai.resolve({ name: '未知物质', online: false }), { status: 503 });
  await assert.rejects(ai.resolve({ name: '' }), { status: 400 });
});
test('DeepSeek uses a closed thinking prefix so structured output is not starved', async (t) => {
  const { ai, calls } = fixture(t, { isMaterial: true, name: '测试树脂', basis: 'population', coefficient: .0001, description: '测试', reasoning: '粗略估算' }, 'xianyan-materials');
  const result = await ai.resolve({ name: '测试树脂', online: false });
  assert.equal(result.material.coefficient, .0001);
  const call = calls.find((c) => c.url.endsWith('/v1/completions'));
  assert.ok(call);
  const payload = JSON.parse(call.options.body);
  assert.ok(payload.prompt.endsWith('<think>\n</think>\n'));
  assert.equal(payload.response_format.type, 'json_schema');
});
test('Ollama adapter selects a chat model and requests structured inventory coefficients', async (t) => {
  const { ai, calls } = fixture(t, { isMaterial: true, name: '测试有机物', basis: 'biomass', coefficient: .002, description: '测试', reasoning: '近似估算' }, null);
  const status = await ai.status();
  assert.equal(status.provider, 'ollama');
  assert.equal(status.model, 'qwen3:4b');
  const result = await ai.resolve({ name: '测试有机物', online: false });
  assert.equal(result.material.coefficient, .002);
  const payload = JSON.parse(calls.find((c) => c.url.endsWith('/api/chat')).options.body);
  assert.equal(payload.think, false);
  assert.ok(payload.format.properties.basis.enum.includes('biomass'));
});
