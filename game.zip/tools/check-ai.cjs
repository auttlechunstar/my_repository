const { createAIService } = require('../local-ai.cjs');
const ai = createAIService();
(async () => {
  console.log(JSON.stringify(await ai.status(true), null, 2));
  const result = await ai.resolve({ name: process.argv.slice(2).find((arg) => !arg.startsWith('--')) || '聚四氟乙烯', online: process.argv.includes('--online') });
  console.log(JSON.stringify(result, null, 2));
})().catch((error) => { console.error(error.message); process.exitCode = 1; });
