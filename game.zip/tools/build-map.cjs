// Development utility: convert world-atlas/countries-110m.json to offline SVG paths.
// Usage: node tools/build-map.cjs /path/to/countries-110m.json
const fs = require('node:fs');
const path = require('node:path');
const topology = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const { scale, translate } = topology.transform;
const arcs = topology.arcs.map((arc) => {
  let x = 0, y = 0;
  return arc.map(([dx, dy]) => {
    x += dx; y += dy;
    return [x * scale[0] + translate[0], y * scale[1] + translate[1]];
  });
});
const ring = (indices) => indices.flatMap((index, i) => {
  const points = index < 0 ? [...arcs[~index]].reverse() : arcs[index];
  return i ? points.slice(1) : points;
});
// Unwrap and clip at the antimeridian, avoiding lines across Russia and Fiji.
function clipEdge(points, edge, keepGreater) {
  if (!points.length) return [];
  const out = [];
  let previous = points[points.length - 1];
  const inside = ([x]) => keepGreater ? x >= edge : x <= edge;
  for (const point of points) {
    if (inside(previous) !== inside(point)) {
      const f = (edge - previous[0]) / (point[0] - previous[0]);
      out.push([edge, previous[1] + (point[1] - previous[1]) * f]);
    }
    if (inside(point)) out.push(point);
    previous = point;
  }
  return out;
}
function projectRing(indices) {
  const unwrapped = [];
  for (const [longitude, latitude] of ring(indices)) {
    let lon = longitude;
    const last = unwrapped[unwrapped.length - 1];
    if (last) { while (lon - last[0] > 180) lon -= 360; while (lon - last[0] < -180) lon += 360; }
    unwrapped.push([lon, latitude]);
  }
  return [-360, 0, 360].map((offset) => {
    const shifted = unwrapped.map(([x, y]) => [x + offset, y]);
    const points = clipEdge(clipEdge(shifted, -180, true), 180, false);
    if (points.length < 3) return '';
    return points.map(([lon, lat], i) => `${i ? 'L' : 'M'}${((lon + 180) / 360 * 1200).toFixed(2)},${((85 - lat) / 145 * 520).toFixed(2)}`).join('') + 'Z';
  }).join('');
}
const geometries = topology.objects.countries.geometries.filter((g) => String(g.id) !== '010');
const paths = geometries.map((g) => {
  const polygons = g.type === 'Polygon' ? [g.arcs] : g.arcs;
  return polygons.map((p) => p.map(projectRing).join('')).join('');
});
fs.writeFileSync(path.join(__dirname, '../assets/world.js'), `// Natural Earth 1:110m / world-atlas 2.0.2. Public domain. See NOTICE.md.\nwindow.WORLD_PATHS = ${JSON.stringify(paths)};\nwindow.WORLD_COUNTRY_IDS = ${JSON.stringify(geometries.map((g) => String(g.id)))};\n`);
console.log(`Generated ${paths.length} country paths.`);
