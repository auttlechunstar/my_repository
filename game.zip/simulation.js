(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Simulation = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = 2;
  const BUDGET = 3000;
  const EARTH_RADIUS = 6371.0088;
  const EARTH_AREA = 4 * Math.PI * EARTH_RADIUS ** 2;
  const SITES = [
    { id: 'east', name: '东方核子中心', location: '中国 · 塔克拉玛干沙漠', code: 'CN-01', lat: 39, lon: 83, dx: -15, dy: 35, anchor: 'end' },
    { id: 'cern', name: '欧洲 CERN', location: '瑞士 · 日内瓦', code: 'CH-02', lat: 46.23, lon: 6.05, dx: -16, dy: 29, anchor: 'end' },
    { id: 'fermi', name: '费米实验室', location: '美国 · 巴达维亚', code: 'US-03', lat: 41.84, lon: -88.26, dx: -16, dy: 29, anchor: 'end' },
    { id: 'kek', name: '日本 KEK', location: '日本 · 筑波', code: 'JP-04', lat: 36.15, lon: 140.08, dx: 16, dy: 23, anchor: 'start' },
    { id: 'ihep', name: '中国高能物理研究所', location: '中国 · 北京', code: 'CN-05', lat: 39.91, lon: 116.24, dx: 10, dy: -23, anchor: 'start' },
    { id: 'dubna', name: '俄罗斯杜布纳', location: '俄罗斯 · 杜布纳', code: 'RU-06', lat: 56.74, lon: 37.19, dx: 14, dy: -20, anchor: 'start' },
  ];
  // Regional assumptions, NOT measured station inventories. All stocks are t/km²,
  // population is people/km². See assets/density-sources.json for scope and references.
  const PROFILES = {
    east: { label: '干旱荒漠 / 科研设施', population: .02, water: 3000, steel: 250, urban: 1600, biomass: 12, crust: 1700000, air: 122500, electronics: .0009 },
    cern: { label: '欧洲城郊 / 湖泊流域', population: 680, water: 2500000, steel: 72000, urban: 480000, biomass: 16000, crust: 1550000, air: 122500, electronics: .032 },
    fermi: { label: '北美城郊 / 农业平原', population: 620, water: 900000, steel: 65000, urban: 420000, biomass: 11000, crust: 1450000, air: 122500, electronics: .028 },
    kek: { label: '日本城郊 / 湿润农田', population: 500, water: 1200000, steel: 54000, urban: 380000, biomass: 17000, crust: 1400000, air: 122500, electronics: .025 },
    ihep: { label: '高密度城市 / 山前平原', population: 4500, water: 250000, steel: 260000, urban: 1600000, biomass: 3200, crust: 1600000, air: 122500, electronics: .19 },
    dubna: { label: '俄罗斯城郊 / 森林河网', population: 230, water: 1800000, steel: 25000, urban: 170000, biomass: 24000, crust: 1300000, air: 122500, electronics: .011 },
  };
  const BASES = ['population', 'water', 'steel', 'urban', 'biomass', 'crust', 'air', 'electronics', 'iron', 'living'];
  const BASIS_LABELS = { population: '人口 × 人均库存', water: '地表及浅层水库存', steel: '钢铁存量', urban: '建成环境材料库存', biomass: '生物量库存', crust: '地表 1 m 土层质量', air: '地表 100 m 空气柱', electronics: '区域芯片库存', iron: '地表铁元素 + 钢铁库存', living: '动植物生物量 + 人体质量' };
  const material = (id, name, aliases, basis, coefficient, extra = {}) => ({ id, name, aliases, basis, coefficient, icon: 'iron', source: 'catalog', uncertainty: '区域近似值，通常存在数量级误差', ...extra });
  const MATERIALS = [
    material('mix', '宏观混合物质', ['混合物', '混合物质', '无特定目标'], 'crust', 1, { icon: 'mix', description: '未指定单一物质，按地表混合物总质量估算。密度较高，共振面积通常很小。', effect: '局部混合物消失', disasters: ['地表扰动'] }),
    material('chip', '电子芯片', ['芯片', '集成电路', 'IC', 'microchip', 'semiconductor chip'], 'electronics', 1, { icon: 'chip', description: '电子芯片共振湮灭，范围内电网、网络与控制设备可能失效。芯片稀少的地区会产生更大的共振面积。', effect: '基础设施失效', disasters: ['区域电网瘫痪', '通信网络中断', '交通信号失效', '数据中心离线', '医院设备停机', '工业控制失灵', '城市供水中断', '供应链中断', '应急指挥受阻'] }),
    material('water', '水', ['H2O', 'H₂O', 'water', '淡水', '水分'], 'water', 1, { icon: 'water', description: '共振面积取决于当地水库存。影响范围内的地表及浅层水消失，可能导致供水中断、局部干旱与火灾。', effect: '水循环受扰', disasters: ['局部失水', '供水中断', '植被干旱', '次生火灾'] }),
    material('iron', '铁', ['Fe', 'iron', '铁元素'], 'iron', 1, { description: '铁元素密度计入地表土层及人造钢铁库存。范围内钢铁结构失稳，建筑与道路可能受损。', effect: '钢铁结构失稳', disasters: ['结构损坏', '道路阻断', '输电设备故障'] }),
    material('carbon', '碳基', ['碳基生命', '生物', '生命体', 'carbon-based life'], 'living', 1, { icon: 'carbon', description: '按动植物生物量与人体质量估算。范围内人类、动物与植物消失，衣物与建筑保留。', effect: '生命迹象消失', disasters: ['局部生命消失', '生态系统受损', '无人设施失控'] }),
    material('hair', '头发', ['毛发', '人类头发', 'hair', 'human hair'], 'population', .00005, { icon: 'hair', description: '按每人约 50 g 头发估算局部库存。人口极稀少时范围可能达到全球，在人口稠密区则明显缩小。', effect: '集体脱发与恐慌', disasters: ['集体恐慌', '异常观测', '社会秩序扰动', '紧急广播启动'] }),
    material('gold', '金', ['黄金', 'Au', 'gold'], 'population', .00003),
    material('silver', '银', ['白银', 'Ag', 'silver'], 'population', .00006),
    material('copper', '铜', ['Cu', 'copper'], 'urban', .008),
    material('aluminum', '铝', ['铝元素', 'Al', 'aluminium', 'aluminum'], 'crust', .0813),
    material('silicon', '硅', ['Si', 'silicon', '硅元素'], 'crust', .277),
    material('oxygen', '氧气', ['O2', 'O₂', 'oxygen'], 'air', .232),
    material('nitrogen', '氮气', ['N2', 'N₂', 'nitrogen'], 'air', .755),
    material('co2', '二氧化碳', ['CO2', 'CO₂', 'carbon dioxide'], 'air', .00064),
    material('carbon-element', '碳元素', ['碳', 'C', 'carbon'], 'crust', .0002),
    material('sodium', '钠', ['Na', 'sodium'], 'crust', .0283),
    material('calcium', '钙', ['Ca', 'calcium'], 'crust', .0363),
    material('magnesium', '镁', ['Mg', 'magnesium'], 'crust', .0209),
    material('titanium', '钛', ['Ti', 'titanium'], 'crust', .0044),
    material('lithium', '锂', ['Li', 'lithium'], 'crust', .00002),
    material('uranium', '铀', ['U', 'uranium'], 'crust', .0000027),
    material('steel', '钢', ['钢铁', '不锈钢', 'steel'], 'steel', 1),
    material('concrete', '混凝土', ['水泥混凝土', 'concrete'], 'urban', .55),
    material('glass', '玻璃', ['glass'], 'urban', .025),
    material('plastic', '塑料', ['塑胶', 'plastic'], 'urban', .012),
    material('wood', '木材', ['木头', 'wood'], 'biomass', .7),
    material('cellulose', '纤维素', ['cellulose'], 'biomass', .38),
    material('chlorophyll', '叶绿素', ['chlorophyll'], 'biomass', .0007),
    material('cotton', '棉花', ['棉', 'cotton'], 'population', .005),
    material('blood', '血液', ['人血', 'blood'], 'population', .005),
    material('dna', 'DNA', ['脱氧核糖核酸', 'dna'], 'living', .0001),
    material('salt', '氯化钠', ['食盐', '盐', 'NaCl', 'sodium chloride'], 'water', .0005),
    material('silica', '二氧化硅', ['石英', '沙子', 'SiO2', 'silica'], 'crust', .55),
    material('rubber', '橡胶', ['rubber'], 'population', .02),
  ];
  const normalize = (name) => String(name).normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
  function findMaterial(name, list = MATERIALS) {
    const key = normalize(name);
    return list.find((m) => [m.name, m.id, ...(m.aliases || [])].some((alias) => normalize(alias) === key));
  }
  function density(material, profile) {
    const base = material.basis === 'iron' ? profile.crust * .035 + profile.steel * .98 : material.basis === 'living' ? profile.biomass + profile.population * .062 : profile[material.basis];
    const value = base * material.coefficient;
    if (!Number.isFinite(value) || value < 0) throw new Error('物质密度无效');
    return value;
  }
  function areaFor(radius) {
    // Stable for sub-meter footprints, unlike 1 - cos(angle).
    return EARTH_AREA * Math.sin(Math.min(Math.PI, radius / EARTH_RADIUS) / 2) ** 2;
  }
  function radiusFor(area) {
    return 2 * EARTH_RADIUS * Math.asin(Math.sqrt(Math.max(0, Math.min(1, area / EARTH_AREA))));
  }
  function footprint(material, profile) {
    const d = density(material, profile);
    if (d === 0) return { density: 0, area: 0, rawArea: null, radius: 0, global: false, mass: 0, available: false };
    const rawArea = BUDGET / d;
    const area = Math.min(rawArea, EARTH_AREA);
    return { density: d, rawArea, area, radius: radiusFor(area), global: rawArea >= EARTH_AREA, mass: Math.min(BUDGET, area * d), available: true };
  }
  function decorate(material, siteId) {
    const f = footprint(material, PROFILES[siteId]);
    return { ...material, ...f, level: f.global ? '全球级' : f.radius >= 500 ? '区域级' : f.radius >= 30 ? '城市级' : f.radius >= 1 ? '局部级' : '微区级', resonance: f.available ? 100 : 0, severity: f.global ? 5 : f.radius >= 500 ? 4 : f.radius >= 30 ? 3 : f.radius >= 1 ? 2 : 1, severityLabel: f.global ? '全球' : f.radius >= 500 ? '极高' : f.radius >= 30 ? '较高' : '局部', subtitle: `${BASIS_LABELS[material.basis]} · 密度决定范围`, effect: material.effect || '目标物质消失', description: material.description || `${material.name}按当地${BASIS_LABELS[material.basis]}估算密度；共振圈内该物质消失，可能引发设施或生态的次生异常。`, disasters: material.disasters || ['目标库存消失', '次生环境异常'], result: material.result || `${material.name}发生湮灭，共振范围按局部密度计算。` };
  }
  function validateMaterial(input) {
    if (!input || typeof input !== 'object' || !BASES.includes(input.basis) || typeof input.name !== 'string' || !input.name.trim() || input.name.length > 60 || !Number.isFinite(input.coefficient) || input.coefficient < 0 || input.coefficient > 1e6) throw new Error('AI 未返回有效的物质或密度系数，请换一种具体名称。');
    if (input.basis !== 'population' && input.coefficient > 1) throw new Error('AI 返回的物质占比超出 0–1，请重试。');
    const name = input.name.trim();
    const id = 'custom-' + Array.from(normalize(name)).reduce((hash, ch) => ((hash * 31 + ch.codePointAt(0)) >>> 0), 0).toString(16);
    return material(id, name, [], input.basis, input.coefficient, { source: 'ai', icon: 'atom', uncertainty: '本地 AI 数量级估算，未经过实测验证', description: String(input.description || '').slice(0, 240), reasoning: String(input.reasoning || '').slice(0, 500) });
  }
  // Global coarse inventory zones: broad biome/settlement scenarios, not a survey raster.
  // Land/ocean is determined with the bundled country polygons in the browser.
  function worldProfile(lon, lat, isLand) {
    if (!isLand) return { label: '海洋', population: 0, water: 1000000, steel: 0, urban: 0, biomass: 30, crust: 0, air: 122500, electronics: 0 };
    const desert = (lat > 15 && lat < 35 && lon > -18 && lon < 62) || (lat > 35 && lat < 46 && lon > 65 && lon < 100) || (lat < -18 && lat > -33 && lon > 115 && lon < 142);
    const forest = Math.abs(lat) < 15 || (lat > 50 && lat < 70);
    if (desert) return { ...PROFILES.east, label: '全球干旱分区', electronics: .00003 };
    if (forest) return { label: '全球森林分区', population: 3, water: 900000, steel: 300, urban: 1800, biomass: 33000, crust: 1400000, air: 122500, electronics: .0001 };
    return { label: '全球温带 / 混合分区', population: 55, water: 350000, steel: 6000, urban: 40000, biomass: 8000, crust: 1550000, air: 122500, electronics: .003 };
  }
  return { VERSION, BUDGET, EARTH_RADIUS, EARTH_AREA, SITES, PROFILES, BASES, BASIS_LABELS, MATERIALS, normalize, findMaterial, density, footprint, decorate, validateMaterial, areaFor, radiusFor, worldProfile };
});
