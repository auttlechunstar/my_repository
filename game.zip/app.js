(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const Engine = window.Simulation;
  const { EARTH_RADIUS, EARTH_AREA, SITES } = Engine;
  const RAD = Math.PI / 180;
  const STORAGE_KEY = 'xianyan-simulation-v2';
  const TARGETS = Engine.MATERIALS.slice(0, 6);
  const customMaterials = new Map();
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const definitionById = (id) => customMaterials.get(id) || Engine.MATERIALS.find((m) => m.id === id);
  const targetById = (id, siteId = site.id) => { const def = definitionById(id); return def ? Engine.decorate(def, siteId) : null; };
  const siteById = (id) => SITES.find((s) => s.id === id);
  let site = SITES[0];
  let target = targetById('chip');
  let records = [];
  let events = [];
  let busy = false;
  let zoom = 1;
  let soundEnabled = false;
  let audioContext;
  let simulationGeneration = 0;
  let toastTimer;
  let totalArea = 0;
  let identifying = false;
  let identifyGeneration = 0;
  let densityVisible = false;
  let densitySources;
  let materialDirty = false;
  let identifyController;
  let aiStatus;
  let worldCells;
  const dateTime = (date = new Date()) => new Date(date).toLocaleTimeString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' });
  const n = (value, decimals = 0) => value.toLocaleString('en-US', { maximumFractionDigits: decimals });
  const project = (lon, lat) => [(lon + 180) / 360 * 1200, (85 - lat) / 145 * 520];
  const areaFor = Engine.areaFor;
  const formatArea = (value) => value >= 1e8 ? [n(value / 1e8, 2), '亿 km²'] : value >= 1e4 ? [n(value / 1e4, 1), '万 km²'] : value > 0 && value < .01 ? [n(value * 1e6, 1), 'm²'] : [n(value, value < 1 ? 4 : 1), 'km²'];
  const formatMass = (value) => value >= 1e8 ? [n(value / 1e8, 2), '亿 t'] : value >= 1e4 ? [n(value / 1e4, 1), '万 t'] : [n(value, 2), 't'];
  const formatRadius = (t) => t.global ? ['全球', 'GLOBAL'] : t.radius < 1 ? [n(t.radius * 1000, 2), 'm'] : [n(t.radius, 2), 'km'];
  const formatDensity = (d) => d > 0 && d < .0001 ? d.toExponential(2) : n(d, d < 1 ? 6 : 2);

  // Equal-area sampling estimates the union of spherical footprints. Identical and
  // globally covering footprints are handled exactly; overlapping areas aren't added twice.
  function distance(a, b) {
    const p1 = a.lat * RAD, p2 = b.lat * RAD;
    const dLat = p2 - p1, dLon = (b.lon - a.lon) * RAD;
    return 2 * EARTH_RADIUS * Math.asin(Math.min(1, Math.sqrt(Math.sin(dLat / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dLon / 2) ** 2)));
  }
  function destination(origin, angle, bearing) {
    const lat = origin.lat * RAD, lon = origin.lon * RAD;
    const latitude = Math.asin(Math.max(-1, Math.min(1, Math.sin(lat) * Math.cos(angle) + Math.cos(lat) * Math.sin(angle) * Math.cos(bearing))));
    const longitude = lon + Math.atan2(Math.sin(bearing) * Math.sin(angle) * Math.cos(lat), Math.cos(angle) - Math.sin(lat) * Math.sin(latitude));
    return { lat: latitude / RAD, lon: ((longitude / RAD + 540) % 360) - 180 };
  }
  function freshArea(record, previous) {
    const origin = siteById(record.siteId), r = record.radius;
    const relevant = previous.filter((p) => distance(origin, siteById(p.siteId)) < r + p.radius);
    if (!relevant.length) return areaFor(r);
    if (relevant.some((p) => p.global || distance(origin, siteById(p.siteId)) + r <= p.radius + 1e-7)) return 0;
    let uncovered = 0;
    const count = 4096, sine = Math.sin(r / (2 * EARTH_RADIUS));
    for (let i = 0; i < count; i++) {
      const point = destination(origin, 2 * Math.asin(Math.sqrt((i + .5) / count) * sine), i * 2.399963229728653);
      if (!relevant.some((p) => distance(point, siteById(p.siteId)) <= p.radius)) uncovered++;
    }
    return areaFor(r) * uncovered / count;
  }
  function calculateTotalArea() {
    if (records.some((r) => r.global)) return EARTH_AREA;
    return records.reduce((sum, r, i) => sum + freshArea(r, records.slice(0, i)), 0);
  }

  function save() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 2, siteId: site.id, targetId: target.id, materials: [...customMaterials.values()], records, events, soundEnabled })); }
    catch { /* The simulation also works when browser storage is disabled. */ }
  }
  function restore() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (!raw || raw.version !== 2) return;
      if (Array.isArray(raw.materials)) for (const saved of raw.materials.slice(0, 100)) {
        try { const valid = Engine.validateMaterial(saved); customMaterials.set(valid.id, { ...valid, evidence: saved.evidence, model: String(saved.model || '').slice(0, 150) }); } catch {}
      }
      if (siteById(raw.siteId)) site = siteById(raw.siteId);
      target = targetById(raw.targetId) || targetById('chip');
      if (Array.isArray(raw.records) && raw.records.length <= 3 && raw.records.every((r) => {
        try { Engine.validateMaterial(r.material); } catch { return false; }
        return siteById(r.siteId) && typeof r.targetId === 'string' && Number.isFinite(r.radius) && r.radius > 0 && r.radius <= Math.PI * EARTH_RADIUS && Number.isFinite(r.density) && r.density > 0 && Number.isFinite(r.mass) && r.mass >= 0 && r.mass <= Engine.BUDGET + 1e-6 && Number.isFinite(r.area) && Math.abs(areaFor(r.radius) - r.area) < Math.max(.000001, r.area * .000001) && Number.isInteger(r.disasters) && r.disasters >= 0 && Number.isFinite(r.timestamp);
      })) records = raw.records;
      if (Array.isArray(raw.events)) events = raw.events.filter((e) => typeof e.text === 'string' && Number.isFinite(e.timestamp)).slice(-40);
      soundEnabled = raw.soundEnabled === true;
    } catch { /* Ignore unavailable or malformed saves. */ }
  }
  function addEvent(text) {
    events.push({ text, timestamp: Date.now() });
    events = events.slice(-40);
    renderEvents();
    save();
  }
  function renderEvents() {
    $('activity-list').replaceChildren();
    [...events].reverse().slice(0, 4).forEach((event) => {
      const div = document.createElement('div');
      div.className = 'activity-item';
      const time = document.createElement('time');
      time.textContent = dateTime(event.timestamp);
      const text = document.createElement('p');
      text.textContent = event.text;
      div.append(time, text);
      $('activity-list').append(div);
    });
    $('log-count').textContent = records.length;
  }
  function toast(text) {
    clearTimeout(toastTimer);
    $('toast').textContent = text;
    $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3500);
  }

  function renderControls() {
    $('station-name').textContent = site.name;
    $('station-location').textContent = site.location;
    $('station-coords').textContent = `${Math.abs(site.lat).toFixed(2)}°${site.lat >= 0 ? 'N' : 'S'} ${Math.abs(site.lon).toFixed(2)}°${site.lon >= 0 ? 'E' : 'W'}`;
    $('station-menu').innerHTML = SITES.map((s) => `<button class="station-option ${s.id === site.id ? 'selected' : ''}" data-site="${s.id}" ${busy ? 'disabled' : ''}>${s.name}<small>${s.location} · ${s.code}</small></button>`).join('');
    $('target-list').innerHTML = TARGETS.map((def) => {
      const t = targetById(def.id), radius = formatRadius(t);
      return `<button class="target-card ${t.id === target.id ? 'selected' : ''}" data-target="${t.id}" title="${escapeHTML(t.name)} · ${formatDensity(t.density)} t/km²" aria-pressed="${t.id === target.id}" ${busy || identifying ? 'disabled' : ''}>${icon(t.icon)}<span><strong>${escapeHTML(t.name)}</strong><small>${radius[0]} ${radius[1]}</small></span><span class="target-radio"></span></button>`;
    }).join('');
    $('station-toggle').disabled = busy;
    $('impact-icon').innerHTML = icon(target.icon);
    $('impact-target').textContent = target.name;
    $('impact-target').title = target.name;
    const radius = formatRadius(target);
    $('radius-value').textContent = radius[0];
    $('radius-unit').textContent = radius[1];
    const area = formatArea(target.area);
    $('area-value').textContent = area[0];
    $('area-unit').textContent = area[1];
    $('range-tag').textContent = target.level;
    document.querySelector('.impact-strip').classList.toggle('global', target.global);
    $('resonance-value').textContent = formatDensity(target.density);
    $('resonance-caption').textContent = target.source === 'ai' ? '本地 AI 估算 · 尚未实测验证' : '预载区域模型 · 近似密度';
    $('density-formula').textContent = `3,000 t ÷ ${formatDensity(target.density)} t/km²`;
    $('density-result').textContent = target.available ? `${formatArea(target.rawArea)[0]} ${formatArea(target.rawArea)[1]}${target.global ? ' → 上限：全球' : ''}` : '该区域无目标物质';
    $('density-region').textContent = `${Engine.PROFILES[site.id].label} · 站点周边 25 km 采样情景`;
    $('selected-material').textContent = `当前目标：${target.name}`;
    $('material-name').disabled = busy || identifying;
    $('identify-material').disabled = busy || identifying;
    $('identify-material').textContent = identifying ? '识别中…' : '识别';
    $('force-ai').disabled = busy || identifying;
    $('effect-type').textContent = target.effect;
    $('effect-description').textContent = target.description;
    $('severity-label').textContent = target.severityLabel;
    [...$('severity-bars').children].forEach((bar, i) => bar.classList.toggle('active', i < target.severity));
    $('map-selection-name').textContent = site.name;
    $('map-selection-code').textContent = site.code;
    renderNodes();
    renderPreview();
    if (densityVisible) renderDensityLayer();
    renderStats();
  }
  function renderStats() {
    const remaining = 3 - records.length;
    $('quota-number').textContent = String(remaining).padStart(2, '0');
    $('remaining-label').textContent = `剩余 ${remaining} 次`;
    [...document.querySelectorAll('.quota-bars span')].forEach((bar, i) => bar.classList.toggle('used', i >= remaining));
    $('launch').disabled = busy || identifying || materialDirty || (!target.available && records.length < 3);
    $('launch-label').textContent = busy ? '共振释放中' : remaining ? '启动对撞' : '查看观测报告';
    $('launch-status').textContent = busy ? '对撞已启动 · 正在观测影响' : identifying ? '正在识别物质 · 请等待' : materialDirty ? '新物质尚未识别 · 请先点击识别' : !target.available ? '此区域无该物质 · 无法共振' : remaining ? '3,000 吨湮灭预算 · 等待指令' : '实验已完成 · 观测报告已生成';
    const area = formatArea(totalArea);
    const mass = formatMass(records.reduce((sum, r) => sum + r.mass, 0));
    $('total-area').innerHTML = `${area[0]}<span> ${area[1]}</span>`;
    $('total-mass').innerHTML = `${mass[0]}<span> ${mass[1]}</span>`;
    $('total-disasters').innerHTML = `${records.reduce((sum, r) => sum + r.disasters, 0)}<span> 起</span>`;
    $('log-count').textContent = records.length;
  }

  function materialStatus(text, kind = '') {
    $('material-status').textContent = text;
    $('material-status').className = `material-status ${kind}`;
  }
  async function checkAI() {
    if (location.protocol === 'file:') {
      aiStatus = { ready: false };
      $('ai-state').textContent = '离线词库 · AI 需本地服务';
      return;
    }
    $('ai-state').textContent = '检测本地 AI…';
    try {
      const response = await fetch('/api/ai/status', { signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error();
      aiStatus = await response.json();
      $('ai-state').textContent = aiStatus.ready ? `${aiStatus.provider === 'ollama' ? 'Ollama' : 'LM Studio'} · 已连接` : '本地 AI 未连接 · 词库可用';
      $('ai-settings').classList.toggle('connected', aiStatus.ready);
      $('ai-settings').title = aiStatus.ready ? aiStatus.model : '点击查看本地 AI 连接方式';
    } catch { aiStatus = { ready: false }; $('ai-state').textContent = 'AI 桥接未运行 · 词库可用'; }
  }
  async function identifyMaterial(forceAI = false) {
    if (busy || identifying) return;
    const name = $('material-name').value.trim() || '宏观混合物质';
    const known = Engine.findMaterial(name, [...Engine.MATERIALS, ...customMaterials.values()]);
    if (known && !forceAI) {
      target = targetById(known.id);
      materialDirty = false;
      $('material-name').value = target.name;
      renderControls();
      materialStatus(`已识别：${target.name} · ${target.source === 'ai' ? 'AI 缓存估算' : '本地物质词库'}`, 'success');
      addEvent(`物质识别完成：${target.name}，已按 ${site.name} 密度计算。`);
      return;
    }
    if (location.protocol === 'file:') return materialStatus('未知物质需要本地 AI。请运行“启动游戏.ps1”，通过 localhost 打开游戏后重试。', 'error');
    identifying = true;
    const generation = ++identifyGeneration;
    identifyController = new AbortController();
    const timeout = setTimeout(() => identifyController?.abort('timeout'), 165000);
    $('identify-cancel').hidden = false;
    renderControls();
    materialStatus('本地 AI 正在识别并估算物质库存；开启联网时会先尝试检索资料。', 'pending');
    try {
      const response = await fetch('/api/material/resolve', { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: identifyController.signal, body: JSON.stringify({ name, online: $('online-research').checked, forceAI }) });
      const body = await response.json();
      if (generation !== identifyGeneration) return;
      if (!response.ok) throw new Error(body.error || '物质识别失败。');
      const canonical = Engine.findMaterial(body.material?.name);
      let material = canonical;
      if (!material) {
        const valid = Engine.validateMaterial(body.material);
        material = { ...valid, evidence: body.material.evidence, model: String(body.material.model || '').slice(0, 150) };
        customMaterials.set(material.id, material);
      }
      target = targetById(material.id);
      materialDirty = false;
      $('material-name').value = target.name;
      const onlineState = body.material.evidence?.status;
      const suffix = onlineState === 'retrieved' ? '已检索物质资料，局部库存仍为估算' : onlineState === 'unavailable' ? '联网暂不可用，使用模型估算' : '密度系数为近似估算';
      materialStatus(`已识别：${target.name} · ${suffix}`, 'success');
      addEvent(`本地 AI 识别：${target.name} · ${suffix}。`);
      save();
    } catch (error) {
      if (generation !== identifyGeneration) return;
      materialStatus(error.name === 'AbortError' || identifyController?.signal.aborted ? '识别已取消或超时，未消耗对撞次数。' : error.message, 'error');
    } finally {
      clearTimeout(timeout);
      if (generation === identifyGeneration) { identifying = false; identifyController = null; $('identify-cancel').hidden = true; renderControls(); }
    }
  }
  function showAISettings() {
    openModal('LOCAL INTELLIGENCE / 本地 AI', `<h2 class="modal-title">本地物质识别</h2><p class="modal-subtitle">${aiStatus?.ready ? `已连接 ${escapeHTML(aiStatus.provider)} · ${escapeHTML(aiStatus.model)}` : '本地物质词库可直接运行。词库外的新物质需连接本机模型服务。'}</p><ol class="guide-list"><li>运行游戏目录中的 <strong>启动游戏.ps1</strong>，访问 localhost 页面。</li><li>在 <strong>LM Studio</strong> 加载聊天模型并启动 <strong>127.0.0.1:1234</strong> 服务；也支持 <strong>Ollama / 11434</strong>。</li><li>输入具体物质名称并点击“识别”。“用 AI 重新识别”可强制调用模型。</li></ol><div class="archive-note">模型负责识别物质和估算库存系数，程序负责单位换算及共振面积计算。联网检索只发送物质名称；网络不可用时会明确标注“模型估算”。抽象概念与无法识别的输入不会消耗对撞次数。</div><div class="modal-actions"><button data-action="check-ai">重新检测连接</button><button class="secondary" data-action="close">返回实验</button></div>`);
  }
  function renderDensityLayer() {
    if (!densityVisible) { $('density-layer').innerHTML = ''; return; }
    if (!worldCells) {
      const ctx = document.createElement('canvas').getContext('2d');
      const paths = (window.WORLD_PATHS || []).map((d) => new Path2D(d));
      worldCells = [];
      for (let lat = -57.5; lat < 85; lat += 5) for (let lon = -177.5; lon < 180; lon += 5) {
        const [x, y] = project(lon, lat);
        const land = paths.some((p) => ctx.isPointInPath(p, x, y, 'evenodd'));
        const nearest = SITES.find((s) => distance(s, { lon, lat }) < 200);
        worldCells.push({ lon, lat, profile: nearest ? Engine.PROFILES[nearest.id] : Engine.worldProfile(lon, lat, land) });
      }
    }
    const cells = worldCells.map((c) => ({ ...c, value: Engine.density(target, c.profile) }));
    const logs = cells.filter((c) => c.value > 0).map((c) => Math.log10(c.value));
    const min = Math.min(...logs), max = Math.max(...logs);
    $('density-layer').innerHTML = cells.filter((c) => c.value > 0).map((c) => {
      const t = (Math.log10(c.value) - min) / (max - min || 1), [x, y] = project(c.lon - 2.5, c.lat + 2.5);
      return `<rect x="${x}" y="${y}" width="16.67" height="17.94" fill="hsl(${205 - t * 165} 80% 60%)" opacity="${.12 + t * .28}"><title>${escapeHTML(c.profile.label)} · ${escapeHTML(target.name)} ≈ ${formatDensity(c.value)} t/km²（分区模型估算）</title></rect>`;
    }).join('');
  }
  async function showDensityDetails() {
    if (!densitySources && location.protocol !== 'file:') { try { densitySources = await (await fetch('assets/density-sources.json')).json(); } catch {} }
    const refs = densitySources?.references || [{ title: 'WorldPop 人口分布参考', url: 'https://www.worldpop.org/' }, { title: 'JRC Global Surface Water', url: 'https://global-surface-water.appspot.com/' }];
    const rows = SITES.map((s) => { const t = targetById(target.id, s.id); const a = formatArea(t.area); return `<tr><td>${s.name}</td><td>${formatDensity(t.density)}</td><td>${a[0]} ${a[1]}</td><td>${formatRadius(t).join(' ')}</td></tr>`; }).join('');
    const sources = (target.evidence?.sources || []).filter((s) => { try { return /^https:$/.test(new URL(s.url).protocol); } catch { return false; } });
    openModal('DENSITY PROVENANCE / 密度计算依据', `<h2 class="modal-title">${escapeHTML(target.name)} · 局部密度模型</h2><p class="modal-subtitle">面积 A = 3,000 t ÷ ρ（t/km²）。圆圈采用等面积球冠半径；面积上限为地球表面积。ρ = 0 时视为无目标物质，不能对撞。</p><div class="archive-note"><strong>${escapeHTML(Engine.BASIS_LABELS[target.basis])}</strong> × ${formatDensity(target.coefficient)}<br>${escapeHTML(target.reasoning || '由预载物质系数与六站点区域参数推算。')}<br>本站 ρ ≈ ${formatDensity(target.density)} t/km²；单次预计湮灭 ${n(target.mass, 2)} t。</div><div class="density-table-wrap"><table class="density-table"><thead><tr><th>站点</th><th>密度 t/km²</th><th>共振面积</th><th>半径</th></tr></thead><tbody>${rows}</tbody></table></div><p class="modal-subtitle">采样口径：站点周边 25 km 的近似情景；土层深度 1 m、大气高度 100 m，包含地表水、生物量与建成环境库存。范围按本站密度外推，未沿传播路径积分。全球 5° 图层为分区模型，六站点参数为人工近似值，尚未导入全球实测栅格。</p><p class="archive-note">${target.source === 'ai' ? '当前物质系数来自本地 AI 估算。' : '当前物质系数来自本地近似词库。'}${target.evidence?.status === 'retrieved' ? '已联网检索物质背景；检索结果不能证明站点库存密度。' : '未取得当次联网实测依据。'} 均不应视为现实物理预测。</p><div class="source-links">${sources.length ? '<strong>当次联网资料</strong>' + sources.map((s) => `<a href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(s.title)}</a>`).join('') : ''}<strong>可用于后续校准的公开数据入口</strong>${refs.map((r) => `<a href="${escapeHTML(r.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(r.title)}</a>`).join('')}</div>`);
  }

  function renderMap() {
    if (Array.isArray(window.WORLD_PATHS)) {
      $('land-base').innerHTML = window.WORLD_PATHS.map((d, i) => `<path d="${d}" data-country="${window.WORLD_COUNTRY_IDS?.[i] || ''}"/>`).join('');
      $('land-dots').innerHTML = window.WORLD_PATHS.map((d) => `<path d="${d}"/>`).join('');
    }
    const [sx, sy] = project(SITES[0].lon, SITES[0].lat);
    $('map-connections').innerHTML = SITES.slice(1).map((s) => {
      const [x, y] = project(s.lon, s.lat);
      return `<path d="M${sx},${sy} Q${(sx + x) / 2},${Math.min(sy, y) - 65} ${x},${y}"/>`;
    }).join('');
  }
  function renderNodes() {
    $('map-nodes').innerHTML = SITES.map((s) => {
      const [x, y] = project(s.lon, s.lat);
      return `<g class="map-node ${s.id === site.id ? 'selected' : ''}" data-site="${s.id}" transform="translate(${x} ${y})" role="button" tabindex="0" aria-label="选择${s.name}" aria-pressed="${s.id === site.id}"><title>${s.name} · ${s.location}</title><circle r="18" fill="transparent"/><circle class="node-halo" r="9"/><circle class="node-ring" r="${s.id === site.id ? 15 : 10}"/><circle class="node-core" r="3.8"/><text x="${s.dx}" y="${s.dy}" text-anchor="${s.anchor}">${s.name}</text><text class="node-code" x="${s.dx}" y="${s.dy + 14}" text-anchor="${s.anchor}">${s.code}</text></g>`;
    }).join('');
  }
  function circlePath(origin, radius) {
    let d = '', last;
    for (let i = 0; i <= 160; i++) {
      const point = destination(origin, Math.min(radius / EARTH_RADIUS, Math.PI - .0001), i / 160 * Math.PI * 2);
      const p = project(point.lon, point.lat);
      d += `${!last || Math.abs(p[0] - last[0]) > 600 ? 'M' : 'L'}${p[0].toFixed(2)},${p[1].toFixed(2)}`;
      last = p;
    }
    return d;
  }
  function renderPreview() {
    const [x, y] = project(site.lon, site.lat);
    document.querySelector('.local-inset')?.remove();
    if (!target.available) {
      $('impact-preview').innerHTML = '';
      return;
    }
    if (target.global) {
      $('impact-preview').innerHTML = `<rect class="global-impact" x="0" y="0" width="1200" height="520"/><rect x="3" y="3" width="1194" height="514" rx="12" fill="none" stroke="#83dcf4" stroke-opacity=".4" stroke-dasharray="5 8"/><ellipse cx="600" cy="260" rx="590" ry="245" class="impact-boundary"/><ellipse cx="600" cy="260" rx="570" ry="230" class="impact-orbit"/><text class="impact-label" x="600" y="470" text-anchor="middle">GLOBAL RESONANCE · ${n(EARTH_AREA)} km²</text>`;
    } else {
      const radiusX = target.radius / (111.195 * Math.cos(site.lat * RAD)) * (1200 / 360);
      const radiusLabel = formatRadius(target).join(' ');
      $('impact-preview').innerHTML = `<path d="${circlePath(site, target.radius)}" class="impact-boundary"/>${target.radius > 100 ? `<path d="${circlePath(site, target.radius * 1.18)}" class="impact-orbit"/><path d="${circlePath(site, target.radius * .77)}" class="impact-orbit"/>` : ''}<path d="M${x - radiusX - 13},${y}h8 M${x + radiusX + 5},${y}h8" stroke="#79d3ec" stroke-opacity=".6"/><text class="impact-label" x="${x}" y="${Math.min(490, y + target.radius / 111.195 * (520 / 145) + 23)}" text-anchor="middle">R ${radiusLabel}</text>`;
      if (target.radius < 100) {
        const div = document.createElement('div');
        div.className = 'local-inset';
        const blocks = Array.from({ length: 16 }, (_, i) => `<rect x="${14 + (i % 4) * 25}" y="${5 + Math.floor(i / 4) * 17}" width="17" height="10" fill="#223d4e" stroke="#436074" stroke-width=".4"/>`).join('');
        div.innerHTML = `<span>局部范围 · 自动适应比例尺</span><svg viewBox="0 0 120 76">${blocks}<circle class="inset-boundary" cx="60" cy="37" r="30" fill="#68cfff15" stroke="#7bdfff" stroke-width=".7" stroke-dasharray="2 3"/><circle cx="60" cy="37" r="2" fill="#d9fbff"/><path d="M60 37h30" stroke="#6dbace" stroke-width=".5"/></svg><small>半径 ${radiusLabel}</small>`;
        $('map-stage').append(div);
      }
    }
  }
  function renderPastImpacts() {
    $('past-impacts').innerHTML = records.map((r) => {
      const s = siteById(r.siteId);
      return r.global ? '<rect width="1200" height="520" fill="#65caff" opacity=".055"/>' : `<path d="${circlePath(s, r.radius)}" fill="#51a9db" fill-opacity=".08" stroke="#65b9dc" stroke-width=".7" stroke-opacity=".3"/>`;
    }).join('');
  }

  function selectSite(id) {
    if (busy) return toast('共振释放中，请等待本次观测完成。');
    const next = siteById(id);
    if (!next) return;
    const changed = site.id !== id;
    site = next;
    target = targetById(target.id);
    $('station-menu').hidden = true;
    $('station-toggle').setAttribute('aria-expanded', 'false');
    applyZoom();
    renderControls();
    if (changed) addEvent(`已连接${site.name}，加速器就绪。`);
    save();
  }
  function selectTarget(id) {
    if (busy || identifying) return;
    const next = targetById(id);
    if (!next) return;
    target = next;
    materialDirty = false;
    $('material-name').value = target.name;
    materialStatus('已选择预设物质，密度已按当前站点更新。');
    renderControls();
    addEvent(`目标已切换：${target.name} · 密度 ${formatDensity(target.density)} t/km² · 半径 ${formatRadius(target).join(' ')}。`);
    save();
    playSound('select');
  }
  function applyZoom() {
    const [x, y] = project(site.lon, site.lat);
    const tx = zoom === 1 ? 0 : Math.max(1200 * (1 - zoom), Math.min(0, 600 - x * zoom));
    const ty = zoom === 1 ? 0 : Math.max(520 * (1 - zoom), Math.min(0, 260 - y * zoom));
    $('map-transform').style.transformOrigin = '0 0';
    $('map-transform').style.transform = `translate(${tx}px,${ty}px) scale(${zoom})`;
    $('map-scale').textContent = `${n(5000 / zoom)} km`;
    $('zoom-in').disabled = zoom >= 4;
    $('zoom-out').disabled = zoom <= 1;
  }

  function playSound(type) {
    if (!soundEnabled) return;
    try {
      audioContext ??= new (window.AudioContext || window.webkitAudioContext)();
      audioContext.resume();
      const now = audioContext.currentTime;
      const osc = audioContext.createOscillator(), gain = audioContext.createGain();
      osc.connect(gain); gain.connect(audioContext.destination);
      osc.type = 'sine';
      const duration = type === 'launch' ? 2.8 : .13;
      osc.frequency.setValueAtTime(type === 'launch' ? 65 : 720, now);
      osc.frequency.exponentialRampToValueAtTime(type === 'launch' ? 360 : 430, now + duration);
      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(type === 'launch' ? .12 : .025, now + .04);
      gain.gain.exponentialRampToValueAtTime(.001, now + duration);
      osc.start(now); osc.stop(now + duration);
    } catch { /* Audio is optional. */ }
  }
  function animateCollision(s, t, generation) {
    const duration = matchMedia('(prefers-reduced-motion: reduce)').matches ? 400 : 3400;
    const start = performance.now();
    const [x, y] = project(s.lon, s.lat);
    const particleCount = 34;
    return new Promise((resolve) => {
      function frame(now) {
        if (generation !== simulationGeneration) { resolve(); return; }
        const progress = Math.min(1, (now - start) / duration);
        let markup = '';
        for (let i = 0; i < 4; i++) {
          const p = Math.max(0, Math.min(1, (progress - i * .13) / (1 - i * .13)));
          if (!p) continue;
          const radius = Math.max(1e-9, t.radius * (1 - (1 - p) ** 2));
          const opacity = Math.sin(p * Math.PI) * (1 - i * .12);
          markup += `<path d="${circlePath(s, Math.min(radius, Math.PI * EARTH_RADIUS * .995))}" class="wave-ring" opacity="${opacity}"/><path d="${circlePath(s, Math.min(radius, Math.PI * EARTH_RADIUS * .995))}" fill="none" stroke="#42bfff" stroke-width="7" filter="url(#wave-glow)" opacity="${opacity * .5}"/>`;
        }
        const particleRadius = Math.max(22, Math.min(t.radius / 111.195 * 3.7, 570));
        for (let i = 0; i < particleCount; i++) {
          const angle = i * 2.39996;
          const speed = .4 + (i % 7) / 10;
          const r = particleRadius * progress * speed;
          markup += `<circle cx="${x + Math.cos(angle) * r}" cy="${y + Math.sin(angle) * r * .65}" r="${i % 3 === 0 ? 1.8 : .8}" fill="#91e9ff" opacity="${(1 - progress) * .9}"/>`;
        }
        markup += `<circle cx="${x}" cy="${y}" r="${6 + 12 * Math.sin(progress * Math.PI)}" fill="#80dcff" opacity="${(1 - progress) * .5}" filter="url(#node-glow)"/>`;
        if (t.global) markup += `<rect width="1200" height="520" fill="#72d7ff" opacity="${Math.sin(progress * Math.PI) * .13}"/>`;
        $('wave-effects').innerHTML = markup;
        if (progress < 1) requestAnimationFrame(frame);
        else { $('wave-effects').innerHTML = ''; resolve(); }
      }
      requestAnimationFrame(frame);
    });
  }
  async function launch() {
    if (busy || identifying) return;
    if (materialDirty) return toast('请先点击“识别”，确认新输入的物质。');
    if (records.length >= 3) return showReport();
    if (!target.available) return toast('此区域内没有可共振的目标物质，请选择其他物质或站点。');
    busy = true;
    const generation = ++simulationGeneration;
    const launchSite = site, launchTarget = target;
    const record = { siteId: site.id, targetId: target.id, material: definitionById(target.id), radius: target.radius, density: target.density, area: target.area, global: target.global, timestamp: Date.now(), mass: 0, disasters: 0, freshArea: 0 };
    const materialArea = freshArea(record, records.filter((r) => r.targetId === target.id));
    const fraction = materialArea / areaFor(target.radius);
    record.freshArea = materialArea;
    record.mass = Math.min(Engine.BUDGET, materialArea * target.density);
    record.disasters = fraction > .001 ? Math.ceil(target.disasters.length * fraction) : 0;
    records.push(record);
    totalArea = calculateTotalArea();
    $('station-menu').hidden = true;
    $('station-toggle').setAttribute('aria-expanded', 'false');
    $('collision-banner').hidden = false;
    document.querySelector('.map-panel').classList.add('colliding');
    renderControls();
    addEvent(`第 ${records.length} 次对撞启动：${site.name} → ${target.name}。`);
    save();
    playSound('launch');
    await animateCollision(launchSite, launchTarget, generation);
    if (generation !== simulationGeneration) return;
    busy = false;
    $('collision-banner').hidden = true;
    document.querySelector('.map-panel').classList.remove('colliding');
    renderPastImpacts();
    renderControls();
    addEvent(fraction > .001 ? launchTarget.result : '该范围内已无新的目标物质，未观测到新增湮灭。');
    save();
    if (records.length === 3) showReport();
    else toast(`观测完成：新增 ${record.disasters} 起连锁事件，剩余 ${3 - records.length} 次对撞。`);
  }

  function openModal(eyebrow, html) {
    $('modal-eyebrow').textContent = eyebrow;
    $('modal-content').innerHTML = html;
    if (!$('modal').open) $('modal').showModal();
  }
  function showReport() {
    const area = formatArea(totalArea), mass = formatMass(records.reduce((sum, r) => sum + r.mass, 0));
    const disasters = records.reduce((sum, r) => sum + r.disasters, 0);
    openModal('FINAL OBSERVATION / 实验结算', `<h2 class="modal-title">世界，已不再如初。</h2><p class="modal-subtitle">三次对撞已完成。以下是本轮宏聚变留下的观测记录。</p><div class="report-grid"><div class="report-stat"><label>累计影响面积</label><strong>${area[0]}</strong><small>${area[1]}</small></div><div class="report-stat"><label>湮灭物质总量</label><strong>${mass[0]}</strong><small>${mass[1]}</small></div><div class="report-stat"><label>连锁灾害数量</label><strong>${disasters}</strong><small>起观测事件</small></div></div>${records.map((r, i) => {
      const s = siteById(r.siteId), safeMaterial = Engine.MATERIALS.find((m) => m.id === r.targetId) || Engine.validateMaterial(r.material), m = formatMass(r.mass);
      const radius = formatRadius({ radius: r.radius, global: r.global }).join(' ');
      return `<div class="report-row">${icon(safeMaterial.icon)}<div><strong>0${i + 1} / ${s.name} · ${escapeHTML(r.material.name)}</strong><p>ρ ${formatDensity(r.density)} t/km² · R ${radius} · ${r.mass > 0 ? `${r.disasters} 起连锁事件` : '无新增物质湮灭'}</p></div><span>${m[0]} ${m[1]}</span></div>`;
    }).join('')}<p class="archive-note">每次对撞的物质湮灭预算为 3,000 吨。全球面积上限与已湮灭区域会使实际值降低；重叠区域不重复累计。各次范围均保存当时的物质密度快照。</p><div class="modal-actions"><button data-action="restart">开始新的实验 ${icon('arrow')}</button><button class="secondary" data-action="close">返回地图</button></div>`);
  }
  function showGuide() {
    openModal('EXPERIMENT PROTOCOL / 操作指南', '<h2 class="modal-title">密度，决定共振的尺度。</h2><p class="modal-subtitle">新规则：共振面积 = 3,000 吨 ÷ 站点附近目标物质密度（吨/平方公里）。物质越稀少，范围越大。</p><ol class="guide-list"><li><strong>选择站点</strong>：点击地图白色节点，密度与范围随站点变化。</li><li><strong>输入物质</strong>：选择预设或输入任意具体物质后点击“识别”。词库外物质由本地 AI 估算，不识别的输入会提示原因。</li><li><strong>查看计算</strong>：地图下方显示公式，点击“数据依据”比较六个站点。小范围附有局部放大图。</li><li><strong>启动对撞</strong>：本轮三次机会，每次最多湮灭 3,000 吨；第三次完成后自动生成报告。</li></ol><div class="archive-note">头发等目标不再固定全球。只有计算面积达到地球表面积时才触发全球共振。区域参数为近似模型，AI 估算与联网背景资料均会标明来源。</div><div class="modal-actions"><button data-action="close">进入实验</button></div>');
  }
  function showArchive() {
    openModal('MACRO ATOM ARCHIVE / 宏原子档案', `<h2 class="modal-title">共振物质档案</h2><p class="modal-subtitle">已预载 ${Engine.MATERIALS.length} 种物质及常见别名。以下范围按当前站点“${site.name}”计算；输入框也支持词库外的本地 AI 识别。</p><div class="archive-list">${[...Engine.MATERIALS, ...customMaterials.values()].map((m) => { const t = targetById(m.id); return `<div class="report-row">${icon(t.icon)}<div><strong>${escapeHTML(t.name)} · ${t.level}</strong><p>ρ ≈ ${formatDensity(t.density)} t/km² · ${escapeHTML(Engine.BASIS_LABELS[t.basis])}</p></div><span>${formatRadius(t).join(' ')}</span></div>`; }).join('')}</div><div class="archive-note">A = 3,000 t / ρ。所有半径都由密度计算，数据是可查看、可调整的近似模型。</div>`);
  }
  function showLogs() {
    openModal('EXPERIMENT LOG / 实验日志', '<h2 class="modal-title">观测时间线</h2><p class="modal-subtitle">本轮对撞、参数调整与异常现象的完整记录 · UTC+8</p><div id="full-log-list"></div>' + (records.length === 3 ? '<div class="modal-actions"><button data-action="report">查看最终报告</button></div>' : ''));
    [...events].reverse().forEach((event) => {
      const row = document.createElement('div');
      row.className = 'log-full-item';
      const time = document.createElement('time');
      time.textContent = dateTime(event.timestamp);
      row.append(time, document.createTextNode(event.text));
      $('full-log-list').append(row);
    });
  }
  function reset() {
    simulationGeneration++;
    identifyGeneration++;
    identifyController?.abort();
    identifying = false;
    materialDirty = false;
    busy = false;
    site = SITES[0]; target = targetById('chip'); records = []; events = []; totalArea = 0; zoom = 1;
    $('material-name').value = target.name;
    $('identify-cancel').hidden = true;
    materialStatus('新一轮实验已就绪。');
    $('modal').close();
    $('wave-effects').innerHTML = '';
    $('collision-banner').hidden = true;
    document.querySelector('.map-panel').classList.remove('colliding');
    applyZoom(); renderPastImpacts(); renderControls();
    addEvent('系统初始化完成，全球 6 个加速器站点在线。');
    addEvent('电子芯片目标已锁定，等待对撞指令。');
    save();
    toast('新一轮实验已就绪 · 3 次对撞机会');
  }

  function drawStars() {
    const canvas = $('starfield'), rect = canvas.getBoundingClientRect(), dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = rect.width * dpr; canvas.height = rect.height * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    let seed = 2048;
    const random = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    for (let i = 0; i < 125; i++) {
      const x = random() * rect.width, y = random() * rect.height;
      ctx.fillStyle = `rgba(143,199,225,${random() * .5 + .1})`;
      ctx.beginPath(); ctx.arc(x, y, random() * .7 + .2, 0, Math.PI * 2); ctx.fill();
    }
  }
  let lastWave = 0;
  function drawWave(now) {
    requestAnimationFrame(drawWave);
    if (document.hidden || now - lastWave < 45) return;
    lastWave = now;
    const canvas = $('waveform'), ctx = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.lineWidth = 1;
    ctx.strokeStyle = '#244254';
    for (let y = 15; y < h; y += 35) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
    for (let x = 0; x < w; x += 48) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
    const phase = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : now / (busy ? 100 : 900);
    const amplitude = !target.available ? 4 : target.global ? 58 : 41;
    for (let layer = 1; layer >= 0; layer--) {
      ctx.beginPath();
      for (let x = 0; x <= w; x++) {
        const envelope = Math.sin(x / w * Math.PI) ** .6;
        const signal = Math.sin(x / 13 + phase + layer * .4) * Math.cos(x / 44 + phase * .2) + Math.sin(x / 6.5 - phase) * .18;
        const y = h / 2 + signal * amplitude * envelope;
        x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.strokeStyle = layer ? '#46b9e850' : '#79d2f2';
      ctx.lineWidth = layer ? 5 : 1.6;
      ctx.shadowColor = '#55c6ff'; ctx.shadowBlur = layer ? 12 : 0;
      ctx.stroke(); ctx.shadowBlur = 0;
    }
  }

  $('target-list').addEventListener('click', (e) => { const b = e.target.closest('[data-target]'); if (b) selectTarget(b.dataset.target); });
  $('station-menu').addEventListener('click', (e) => { const b = e.target.closest('[data-site]'); if (b) selectSite(b.dataset.site); });
  $('station-toggle').addEventListener('click', () => { $('station-menu').hidden = !$('station-menu').hidden; $('station-toggle').setAttribute('aria-expanded', String(!$('station-menu').hidden)); });
  document.addEventListener('click', (e) => { if (!e.target.closest('.station-picker')) { $('station-menu').hidden = true; $('station-toggle').setAttribute('aria-expanded', 'false'); } });
  $('map-nodes').addEventListener('click', (e) => { const node = e.target.closest('[data-site]'); if (node) selectSite(node.dataset.site); });
  $('map-nodes').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { const node = e.target.closest('[data-site]'); if (node) { e.preventDefault(); selectSite(node.dataset.site); } } });
  $('launch').addEventListener('click', launch);
  $('material-form').addEventListener('submit', (e) => { e.preventDefault(); identifyMaterial(); });
  $('force-ai').addEventListener('click', () => identifyMaterial(true));
  $('material-name').addEventListener('input', () => {
    const known = Engine.findMaterial($('material-name').value, [...Engine.MATERIALS, ...customMaterials.values()]);
    materialDirty = !known || known.id !== target.id;
    materialStatus(materialDirty ? '输入已改变，请点击“识别”更新目标与范围。' : '当前输入与已锁定物质一致。');
    renderStats();
  });
  $('identify-cancel').addEventListener('click', () => {
    identifyGeneration++;
    identifyController?.abort();
    identifyController = null;
    identifying = false;
    $('identify-cancel').hidden = true;
    materialStatus('识别已取消，未消耗对撞次数。');
    renderControls();
  });
  $('ai-settings').addEventListener('click', showAISettings);
  $('density-details').addEventListener('click', showDensityDetails);
  $('density-toggle').addEventListener('click', () => {
    densityVisible = !densityVisible;
    $('density-toggle').setAttribute('aria-pressed', String(densityVisible));
    $('density-legend').hidden = !densityVisible;
    renderDensityLayer();
  });
  $('zoom-in').addEventListener('click', () => { zoom = Math.min(4, zoom + .5); applyZoom(); });
  $('zoom-out').addEventListener('click', () => { zoom = Math.max(1, zoom - .5); applyZoom(); });
  $('zoom-reset').addEventListener('click', () => { zoom = 1; applyZoom(); });
  $('fullscreen').addEventListener('click', async () => {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.querySelector('.map-panel').requestFullscreen(); }
    catch { toast('当前浏览器不支持全屏，请使用地图缩放按钮。'); }
  });
  $('help').addEventListener('click', showGuide);
  $('target-help').addEventListener('click', showArchive);
  $('all-logs').addEventListener('click', showLogs);
  document.querySelectorAll('[data-view]').forEach((b) => b.addEventListener('click', () => {
    if (b.dataset.view === 'archive') showArchive();
    if (b.dataset.view === 'logs') showLogs();
    if (b.dataset.view === 'console') { $('modal').close(); document.querySelector('.page-heading').scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  }));
  $('modal-close').addEventListener('click', () => $('modal').close());
  $('modal').addEventListener('click', (e) => {
    if (e.target === $('modal')) { const rect = $('modal').getBoundingClientRect(); if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) $('modal').close(); }
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'close') $('modal').close();
    if (action === 'restart') reset();
    if (action === 'report') showReport();
    if (action === 'check-ai') { $('modal').close(); checkAI(); }
  });
  $('reset').addEventListener('click', () => {
    if (!records.length) return reset();
    openModal('REINITIALIZE / 重新模拟', '<h2 class="modal-title">开启新的实验？</h2><p class="modal-subtitle">这会清除本轮对撞记录、累计影响与观测报告，重新获得 3 次对撞机会。</p><div class="modal-actions"><button data-action="restart">开始新的实验</button><button class="secondary" data-action="close">保留当前实验</button></div>');
  });
  function updateSound() {
    $('sound-toggle').classList.toggle('sound-off', !soundEnabled);
    $('sound-toggle').setAttribute('aria-pressed', String(soundEnabled));
    $('sound-toggle').title = soundEnabled ? '关闭音效' : '开启音效';
    $('sound-toggle').setAttribute('aria-label', $('sound-toggle').title);
  }
  $('sound-toggle').addEventListener('click', () => { soundEnabled = !soundEnabled; updateSound(); save(); playSound('select'); toast(soundEnabled ? '实验音效已开启' : '实验音效已关闭'); });
  new ResizeObserver(drawStars).observe($('map-stage'));
  setInterval(() => { $('clock').textContent = `UTC+8 ${dateTime()}`; }, 1000);
  $('clock').textContent = `UTC+8 ${dateTime()}`;
  restore();
  $('material-name').value = target.name;
  totalArea = calculateTotalArea();
  renderMap(); renderPastImpacts(); renderControls(); renderEvents(); updateSound();
  if (!events.length) { addEvent('系统初始化完成，全球 6 个加速器站点在线。'); addEvent('电子芯片目标已锁定，等待对撞指令。'); }
  requestAnimationFrame(drawWave);
  checkAI();
  if (records.length === 3) showReport();
})();
