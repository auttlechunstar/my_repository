// Local game server and local-only LM Studio / Ollama bridge.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { createAIService } = require('./local-ai.cjs');
const ai = createAIService();
const root = __dirname;
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };
const port = Number(process.env.PORT) || 3000;
const json = (res, code, value) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); };
async function readJSON(req) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body) > 8192) throw Object.assign(new Error('请求内容过长。'), { status: 413 });
  }
  try { return JSON.parse(body); }
  catch { throw Object.assign(new Error('无效的 JSON 请求。'), { status: 400 }); }
}
const server = http.createServer(async (req, res) => {
  let name;
  try { name = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400).end('Bad request'); return; }
  if (name.startsWith('/api/')) {
    const allowed = new Set([`localhost:${port}`, `127.0.0.1:${port}`]);
    if (!allowed.has(req.headers.host)) return json(res, 403, { error: '仅允许本机游戏访问。' });
    if (req.headers.origin) {
      let originHost;
      try { originHost = new URL(req.headers.origin).host; } catch { return json(res, 403, { error: '无效的来源。' }); }
      if (!allowed.has(originHost)) return json(res, 403, { error: '跨站请求已拒绝。' });
    }
    try {
      if (name === '/api/ai/status' && req.method === 'GET') { const status = await ai.status(); const { base, ...publicStatus } = status; return json(res, 200, publicStatus); }
      if (name === '/api/material/resolve' && req.method === 'POST') return json(res, 200, await ai.resolve(await readJSON(req)));
      return json(res, 404, { error: '接口不存在。' });
    } catch (error) { return json(res, error.status || 500, { error: error.status ? error.message : '服务暂时不可用，请重试。' }); }
  }
  const file = path.resolve(root, '.' + (name === '/' ? '/index.html' : name));
  if (!file.startsWith(root + path.sep) || name.startsWith('/data/') || /(?:^|\/)\./.test(name)) { res.writeHead(403).end('Forbidden'); return; }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404).end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});
server.requestTimeout = 180000;
server.on('error', (error) => { console.error(error.code === 'EADDRINUSE' ? `端口 ${port} 已被使用。可设置 PORT 后重试。` : error.message); process.exitCode = 1; });
server.listen(port, '127.0.0.1', () => console.log(`Xianyan ready at http://localhost:${port}`));
